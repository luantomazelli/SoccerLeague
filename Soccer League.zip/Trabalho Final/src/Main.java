/*
 * Teste.java
 * 
 * Created on 11/11/2007, 16:01:04
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Leandro H.Soares
 *         Luan Tomazelli 
 */
public class Main {
    public static void main(String args[]){
        JFramePrincipal janela = new JFramePrincipal();
        janela.setVisible(true);
        
    }

}
