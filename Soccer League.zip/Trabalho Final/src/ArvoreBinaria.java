
import java.io.Serializable;
import java.util.*;
/**
 *
 * 
 * @author Leandro H.Soares
 *         Luan Tomazelli 
 */

public class ArvoreBinaria<E> implements Serializable{
    private Nodo<E> raiz;
    private ArrayList<E> lista = new ArrayList<E>();
    private class Nodo<T> implements Serializable{
        private T element;
        private Nodo<T> esq;
        private Nodo<T> dir;
        public Nodo(T e) {
            element = e;
            esq = null;
            dir = null;
        }
        public void setElement(T e) {
            element = e; 
        }
        public void setEsquerda (Nodo<T> n) { 
            esq = n; 
        }
        public void setDireita (Nodo<T> n) { 
            dir = n; 
        }        
        public T getElement() { 
            return element; 
        }
        public Nodo<T> getEsquerda() { 
            return esq; 
        }
        public Nodo<T> getDireita() { 
            return dir; 
        }
    }
    
    public ArvoreBinaria()
    {
        raiz = null;
    }
    
    
    // Retorna verdadeiro quando encontra o 
    // objeto d na arvore binaria
    public boolean pesquisa(E d)
    {
        Nodo<E> aux = pesquisa(raiz,d);

        if (aux == null)
          return false;

        return true;
    }

    // Metodo recursivo e privado que procura um objeto d na 
    // Arvore, quando o encontra devolve a sua referencia
    private Nodo<E> pesquisa(Nodo<E> a, E d)
    {
        Nodo<E> aux; 

        if (a == null)
          return null;
        if ( a.getElement().equals(d) )
          return a;

        aux = pesquisa(a.getEsquerda(),d);
        if (aux==null)
          aux = pesquisa(a.getDireita(),d);

        return aux;
    }
    // Metodo que retorna o elemento pai    
    public E pesquisaPai(E d)
    {
        if (d.equals(raiz.getElement()))
            return null;
        Nodo<E> a = pesquisaPai(raiz, d, null);
        return a.getElement();
    }
    
    // Metodo que retorna o nodo do elemento pai    
    private Nodo<E> pesquisaNodoPai(E d)
    {
        if (d.equals(raiz.getElement()))
            return null;
        Nodo<E> a = pesquisaPai(raiz, d, null);
        return a;
    }
    
    // Metodo recursivo e privado que procura um objeto d na arvore,
    // quando o encontra devolve a sua referencia para o seu nodo pai
    private Nodo<E> pesquisaPai(Nodo<E> a, E d, Nodo<E> pai)
    {
        Nodo<E> aux; 

        if (a == null)
          return null;
        if ( a.getElement().equals(d) )
          return pai;

        aux = pesquisaPai(a.getEsquerda(), d, a);
        if (aux==null)
          aux = pesquisaPai(a.getDireita(), d, a);

        return aux;
    }     
    
    // Insere um objeto na raiz, no caso da �rvore esta
    // vazia. Retorna falso se a �rvore j� tiver elementos
    public boolean insere(E d)
    {
        if (raiz == null)
        {
           raiz = new Nodo<E>(d); 
           return true;
        }
        else
            return false;
    }
    
    // Insere o objeto d como filho do objeto Pai,a esquerda 
    // se pos for 1 e a direita, se for 2. Nao permite a 
    // insercao de objetos iguais
    public boolean insere(E d, E pai, int pos)
    {
        Nodo<E> aux;

        if( d == null || pai == null || pos!=1 && pos!=2)
            return false;
     
        aux = pesquisa(raiz,d);
        if (aux != null)
            return false;
 
        aux = pesquisa(raiz,pai);
        if (aux == null)
            return false;

        if (pos == 1)
            if (aux.getEsquerda()!=null)
                return false;
            else 
                aux.setEsquerda(new Nodo<E>(d));
        else 
            if (aux.getDireita()!=null)
                return false;
            else 
                aux.setDireita(new Nodo<E>(d));

        return true;
    }

    // Verifica se um determinado elemento � a raiz da �rvore
    public boolean ehRaiz(E e)
    {
    	if (raiz != null)
            if (raiz.getElement().equals(e))
            	return true;
         return false;
    }

    // Retorna o total de Nodo<E>s armazenados na �rvore
    public int getTotalNodos()
    {
        return quantidadeNodos(raiz);
    }

    private int quantidadeNodos(Nodo<E> a)
    {
        if (a == null )
            return 0;
        return quantidadeNodos(a.getEsquerda()) + quantidadeNodos(a.getDireita()) + 1;
    }   
       
    public void mostraPreOrdem()
    {
        mostraPreOrdem(raiz);
    }
    
    private void mostraPreOrdem (Nodo<E> n)
    {
        if (n == null)
            return;
        
        System.out.println(n.getElement().toString());
        mostraPreOrdem(n.getEsquerda());
        mostraPreOrdem(n.getDireita());
    }

    public void mostraCentralOrdem()
    {
        mostraCentralOrdem(raiz);
    }
    
    private void mostraCentralOrdem (Nodo<E> n)
    {
        if (n == null)
            return;
        
        mostraCentralOrdem(n.getEsquerda());
        System.out.println(n.getElement().toString());        
        mostraCentralOrdem(n.getDireita());
    }

    public void mostraPosOrdem(){
        mostraPosOrdem(raiz);
    }
    
    private void mostraPosOrdem (Nodo<E> n)
    {
        if (n == null)
            return;
        
        mostraPosOrdem(n.getEsquerda());
        mostraPosOrdem(n.getDireita());
        System.out.println(n.getElement().toString());        
    }   
    
    public boolean remove(E  d){ 
        if(!pesquisa(d)) return false;
        if(pesquisaNodoPai(d)==null){
            raiz=null;
            return true;
        }
        Nodo<E> aux = pesquisaNodoPai(d);
        if(aux.getDireita().getElement()==d)
            aux.setDireita(null);
        else
            aux.setEsquerda(null);
        return true;
    }
    
    public int nivel(E e){
        if(!pesquisa(e)) 
            return -1;
        if(pesquisaPai(e)==null) 
            return 0;
        
        Nodo<E> aux = pesquisaNodoPai(e);
        
        return 1+nivel(aux.getElement());
    }
    
    public E getRaiz(){
        if(raiz==null) return null;
        return raiz.getElement();
    }
    
    public boolean ehInterno(E e){
        if(!pesquisa(e)) 
            return false;
        if(pesquisaPai(e)==null)
            return false;
        Nodo<E> aux = pesquisa(raiz, e);
        if(aux.getDireita()!=null || aux.getEsquerda()!=null)
            return true;
        return false;
    }
    
    public boolean ehFolha(E d){
        if(!pesquisa(d)) 
            return false;
        if(pesquisaPai(d)==null)
            return false;
        Nodo<E> aux = pesquisa(raiz, d);
        if(aux.getDireita()==null && aux.getEsquerda()==null)
            return true;
        return false;
    }
    public E getDireita(E e){
        if(!pesquisa(e)) 
            return null;
        Nodo<E> aux = pesquisaNodoPai(e);
        if(aux.getDireita()!=null)
            return aux.getDireita().getElement();
        return null;
    }
    
    public E getEsquerda(E e){
        if(!pesquisa(e)) 
            return null;
        Nodo<E> aux = pesquisaNodoPai(e);
        if(aux.getEsquerda()!=null)
            return aux.getEsquerda().getElement();
        return null;
    }
    
    public int altura (){
        if(raiz==null)
            return -1;
        return altura(raiz);
        
    }
    private int altura(Nodo<E> n){
        if(n==null)
            return -1;
        int i, j;
        
        i = 1+altura(n.getEsquerda());
        j = 1+altura(n.getDireita());

        if(i>j)
            return i;
        return j;
    }
    
    public ArrayList<E> retornaElementosOrdenados()
    {
    	ArrayList<E> array = new ArrayList<E>();
    	incluiElementosOrdenados(array,raiz);
    	return array;
    }
    
    private void incluiElementosOrdenados(ArrayList<E> array, Nodo<E> n)
    {
        if (n != null)
        {
        	incluiElementosOrdenados(array,n.getEsquerda());
        	array.add(n.getElement());
        	incluiElementosOrdenados(array,n.getDireita());
        }
        return;
    }
    
    public ArrayList<E> retornaElementosEmLargura() {
    	ArrayList<E> array = new ArrayList<E>();
        Fila<Nodo<E>> fila = new Fila<Nodo<E>>();
        if (raiz != null)
        {
	        fila.enqueue(raiz);
	        while(!fila.isEmpty())
	        {
	            Nodo<E> n = fila.dequeue();
	            array.add(n.getElement());
	            if (n.getEsquerda() != null)
	            	fila.enqueue(n.getEsquerda());
	            if (n.getDireita() != null)
	            	fila.enqueue(n.getDireita());
	        }
        }
    	return array;    	
    }
}
