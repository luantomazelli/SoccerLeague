import java.io.Serializable;
import java.util.*;
/**
 *
 * @author Leandro H.Soares
 *         Luan Tomazelli 
 */
public class Fila<E> implements Queue<E>, Serializable{
    private List<E> fila;
    

    public Fila(){
        fila = new LinkedList<E>();
    }
    
    public int size() {
        return fila.size();
    }

    public boolean isEmpty() {
        return fila.isEmpty();
    }

    public E front() throws EmptyQueueException {
        E element = fila.get(size()-1);
        return element;
    }

    public void enqueue(E element) {
        fila.add(0, element);
    }

    public E dequeue() throws EmptyQueueException {
        if(fila.isEmpty())
            throw new EmptyQueueException("A fila est� vazia");
        E element = fila.get(size()-1);
        fila.remove(size()-1);
        return element;

    }

}
