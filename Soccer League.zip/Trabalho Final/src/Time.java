import java.io.Serializable;
import java.util.*;
/*
 * Time.java
 *
 * Created on 18 de Outubro de 2007, 13:41
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 */
/**
 *
 * @author Leandro H.Soares
 *         Luan Tomazelli 
 */
public class Time implements Serializable{
    
    private String nome;
    private Escalacao escalacao;
    private int golsPro=0, golsContra=0;
    
    /** Creates a new instance of Time */
    public Time(String nome, Escalacao e) {
        this.nome=nome;
        escalacao = new Escalacao();
        escalacao = e;
    }

    //Apenas para teste
    public Time(String nomeTime, String j) {
        escalacao = new Escalacao();
        nome=nomeTime;
        escalacao.addJogador(j, nome);
    }
    
    public void setNome(String n){
        nome = n;
    }
    public String getNome(){
        return nome;
    }
    public void setGolsPro(int g){
        golsPro = golsPro + g;
    }
    public int getGolsPro(){
        return golsPro;
    }
    public void resetGols(){
        golsPro = 0;
        golsContra = 0;
    }
    public void setGolsContra(int g){
        golsContra = golsContra + g;
    }
    public int getGolsContra(){
        return golsContra;
    }
    public int saldoDeGols(){
        return (golsPro-golsContra);
    }
    public boolean addJogador(Jogador j){
        return escalacao.addJogador(j);
    }
    public String getJogador(){
        //String jogador = escalacao.todos();
        return escalacao.todos();
    }
    public ArrayList<Jogador> getEscalacao(){
        ArrayList<Jogador> todosJogadores = new ArrayList<Jogador>();
        for(int i=0; i<escalacao.tamanho();i++)
            todosJogadores.add(i, escalacao.get(i));
        //System.out.println(todosJogadores.get(0));TESTAR!!
        return todosJogadores;        
    }
    
    public String toString(){
        return "Nome do time: "+nome+"\nJogadores:"+getJogador();
    }
    
}
