import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
/**
 * CadastroDeTimes.java
 *
 * Created on 18 de Outubro de 2007, 13:41
 *
 * To change this template, choose Tools | Template Manager
 * and open the template in the editor.
 *
 * @author Leandro H.Soares
 *         Luan Tomazelli 
 */
public class CadastroDeTimes implements Serializable{
    
    private List<Time> lista;
    private List<Time> listaSaldo;
    private Time time;
    private Jogador jogador;
    
    /** Creates a new instance of CadastroDeTimes */
    public CadastroDeTimes() {
        lista = new ArrayList<Time>(16); 
    }
    
    public boolean addTime(Time t){
        return lista.add(t);
    }
    
    public boolean removeTime(Time t){
        return lista.remove(t);
    }
    public boolean removeTime(String nome){
        if(tamanho()==0)
            return false;
        else{
            for(Time t: lista)
                if (t.getNome().equalsIgnoreCase(nome))
                    return removeTime(t);
            }
        return false;
    }
    
    public int tamanho(){
        return lista.size();
    }
    public boolean contem(String s){
        for(Time t:lista)
            if(t.getNome().equalsIgnoreCase(s))
                return true;
        return false;
    }
    
    public boolean contem(Time ti){
        for(Time t:lista)
            if(ti==t)
                return true;
        return false;
    }

    public boolean verificaIndice(int index){
        if(index <0 || index>tamanho() || lista.get(index)==null)  
            return false;
        return true;
    }
    
    public Time set(int i, Time t){
        return lista.set(i, time);
    }
    
    public Time getTime(int index){
        if(index<0 || index>tamanho())
            return null;
        return lista.get(index);
        
    }
    
    public boolean excluirTime(String t){
        for(Time ti:lista){
            if(ti.getNome().equalsIgnoreCase(t)){
                lista.remove(ti);
                return true;
            }
        }
        return false;
    }
    
    public void comparaSaldo(){
        listaSaldo = lista;
        Time j1,j2;
        for(int i=0; i<(tamanho()-1); i++){
            if(listaSaldo.get(i).getGolsPro()<listaSaldo.get(i+1).getGolsPro()){
                j1=listaSaldo.get(i);
                j2=listaSaldo.get(i+1);
                listaSaldo.set(i, j2);
                listaSaldo.set(i+1, j1);
                i=0;
            }
        }
    }

    public String getMelhorAtaque(){
        comparaSaldo();
        if(listaSaldo.get(0).getGolsPro()==0)
            return "Nenhum time fez gol at� o momento";
        return "O time "+listaSaldo.get(0).getNome()+" tem o melhor ataque, com "+listaSaldo.get(0).getGolsPro()+" gols.";
    }
    
    public String getPiorDefesa(){
        comparaSaldo();
        Time aux = lista.get(0);
        if(listaSaldo.get(0).getGolsPro()==0)
            return "Nenhum time fez gol at� o momento";
        for(int i=1; i<tamanho();i++){
            if(aux.getGolsContra()<listaSaldo.get(i).getGolsContra()){
                aux = listaSaldo.get(i);
                i=1;
            }
        }
        return "O time "+aux.getNome()+" tem a pior defesa, com "+aux.getGolsContra()+" gols sofridos";
    }
 
    public boolean gravaArquivoBinario(){
        try{
            FileOutputStream os = new FileOutputStream("cadastroDeTimes.jog");
            ObjectOutputStream oarq = new ObjectOutputStream(os);
            oarq.writeObject(lista);
            oarq.writeObject(listaSaldo);
            oarq.close();
            return true;
    	}
    	catch(IOException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            e.printStackTrace();
    	}
    	return false;
    }
    @SuppressWarnings("unchecked")
    public boolean leArquivoBinario(){ 
    	try{
            FileInputStream is = new FileInputStream("cadastroDeTimes.jog");
            ObjectInputStream iarq = new ObjectInputStream(is);
            lista = (ArrayList<Time>) iarq.readObject();
            listaSaldo = (ArrayList<Time>) iarq.readObject();
            iarq.close();
            return true;
    	}
    	catch(IOException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            e.printStackTrace();
    	}
    	catch(ClassNotFoundException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            e.printStackTrace();
    	}
    	return false;
    }
    
    

}
