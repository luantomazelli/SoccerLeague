import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
/*
 * Campeonato.java
 * 
 * Created on 02/11/2007, 21:34:44
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Leandro H.Soares
 *         Luan Tomazelli 
 */
public class Campeonato implements Serializable{
    Random generator = new Random();
    static int numJogo=1;
    private int randomIndex, numPartida, numTimeA, numTimeB;
    private ArvoreBinaria<Jogo> cadastroDeJogos;
    private ArrayList<Jogo> listaAux;
    private CadastroDeTimes times = new CadastroDeTimes();
    private Jogo jogo1, jogo2, jogo3, jogo4, jogo5, jogo6, jogo7, jogo8;
    
    private Jogo jogo15 = new Jogo("Vencedor Jogo13","Vencedor Jogo14",15);
    private Jogo jogo14 = new Jogo("Vencedor Jogo11","Vencedor Jogo12",14);
    private Jogo jogo13 = new Jogo("Vencedor Jogo9","Vencedor Jogo10",13);
    private Jogo jogo12 = new Jogo("Vencedor Jogo7","Vencedor Jogo8",12);
    private Jogo jogo11 = new Jogo("Vencedor Jogo5","Vencedor Jogo6",11);
    private Jogo jogo10 = new Jogo("Vencedor Jogo3","Vencedor Jogo4",10);
    private Jogo jogo9 = new Jogo("Vencedor Jogo1","Vencedor Jogo2", 9);
    
    
    public void sorteio(CadastroDeTimes lista){ //pega os 16 times e joga em uma pilha, randomicamente
        while(times.tamanho()<lista.tamanho()){
            randomIndex = generator.nextInt(16);           
            if(!times.contem(lista.getTime(randomIndex)))
                times.addTime(lista.getTime(randomIndex));
        }
    }
    
    public Campeonato(){
        cadastroDeJogos = new ArvoreBinaria<Jogo>();
    }
    
    public void iniciaCampeonato(){
        jogo8 = new Jogo(times.getTime(0), times.getTime(1),8);        //Instancia os 16 times
        jogo7 = new Jogo(times.getTime(2), times.getTime(3),7);
        jogo6 = new Jogo(times.getTime(4), times.getTime(5),6);
        jogo5 = new Jogo(times.getTime(6), times.getTime(7),5);
        jogo4 = new Jogo(times.getTime(8), times.getTime(9),4);
        jogo3 = new Jogo(times.getTime(10), times.getTime(11),3);
        jogo2 = new Jogo(times.getTime(12), times.getTime(13),2);
        jogo1 = new Jogo(times.getTime(14), times.getTime(15),1);
        atualizaCampeonato();
    }
        
        //insere todos os jogos na arvore
    public void atualizaCampeonato(){
        cadastroDeJogos.insere(jogo15);
        cadastroDeJogos.insere(jogo14,jogo15, 2);
        cadastroDeJogos.insere(jogo13,jogo15, 1);
        cadastroDeJogos.insere(jogo12,jogo14, 2);
        cadastroDeJogos.insere(jogo11,jogo14, 1);
        cadastroDeJogos.insere(jogo10,jogo13, 2);
        cadastroDeJogos.insere(jogo9,jogo13, 1);
        cadastroDeJogos.insere(jogo8,jogo12, 2);
        cadastroDeJogos.insere(jogo7,jogo12, 1);
        cadastroDeJogos.insere(jogo6,jogo11, 2);
        cadastroDeJogos.insere(jogo5,jogo11, 1);
        cadastroDeJogos.insere(jogo4,jogo10, 2);
        cadastroDeJogos.insere(jogo3,jogo10, 1);
        cadastroDeJogos.insere(jogo2,jogo9, 2);
        cadastroDeJogos.insere(jogo1,jogo9, 1);
        listaAux = cadastroDeJogos.retornaElementosEmLargura();
    }
    
    public Jogo nextGame(){
        Jogo partida = new Jogo();
        atualizaResultados();
        partida = pesquisaNumJogo(numJogo);
        numJogo++;
        return partida;
    }
    
    public void atualizaResultados(){
            jogo9.setTimeA(pesquisaNumJogo(1).getVencedor());
            jogo9.setTimeB(pesquisaNumJogo(2).getVencedor());
            jogo10.setTimeA(pesquisaNumJogo(3).getVencedor());
            jogo10.setTimeB(pesquisaNumJogo(4).getVencedor());
            jogo11.setTimeA(pesquisaNumJogo(5).getVencedor());
            jogo11.setTimeB(pesquisaNumJogo(6).getVencedor());
            jogo12.setTimeA(pesquisaNumJogo(7).getVencedor());
            jogo12.setTimeB(pesquisaNumJogo(8).getVencedor());
            jogo13.setTimeA(pesquisaNumJogo(9).getVencedor());
            jogo13.setTimeB(pesquisaNumJogo(10).getVencedor());
            jogo14.setTimeA(pesquisaNumJogo(11).getVencedor());
            jogo14.setTimeB(pesquisaNumJogo(12).getVencedor());
            jogo15.setTimeA(pesquisaNumJogo(13).getVencedor());
            jogo15.setTimeB(pesquisaNumJogo(14).getVencedor());
            atualizaCampeonato();
        
    }
    public Jogo getJogoAnterior(){
        try{
            return pesquisaNumJogo(numJogo-2);
        }
        catch(NullPointerException ex)
        {
            return null;
        }
            
    }
    public Jogo getJogoAtual(){
        return pesquisaNumJogo(numJogo-1);
    }
    
    public int penalti(){
        return randomIndex = generator.nextInt(2);
    }
    
    public Jogo pesquisaNumJogo(int n){
        for(Jogo j:listaAux)
            if(j.getNumJogo()==n)
                return j;
        return null;
    }

    public void resultado(Jogo jogoDaVez){
        for(Jogo j:listaAux)
            if(j.getNumJogo()==jogoDaVez.getNumJogo())
                j=jogoDaVez;
        atualizaSaldo(jogoDaVez);
    }
    
    public boolean gravaArquivoBinario(){
        try{
            FileOutputStream os = new FileOutputStream("campeonato.jog");
            ObjectOutputStream oarq = new ObjectOutputStream(os);
            oarq.writeInt(numJogo);
            oarq.writeObject(cadastroDeJogos);
            oarq.writeObject(listaAux);
            oarq.writeObject(times);
            oarq.writeObject(jogo15);
            oarq.writeObject(jogo14);
            oarq.writeObject(jogo13);
            oarq.writeObject(jogo12);
            oarq.writeObject(jogo11);
            oarq.writeObject(jogo10);
            oarq.writeObject(jogo9);
            oarq.close();
            return true;
    	}
    	catch(IOException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            e.printStackTrace();
    	}
    	return false;
    }
    @SuppressWarnings("unchecked")
    public boolean leArquivoBinario(){ 
    	try{
            FileInputStream is = new FileInputStream("campeonato.jog");
            ObjectInputStream iarq = new ObjectInputStream(is);
            numJogo = iarq.readInt();
            cadastroDeJogos = (ArvoreBinaria<Jogo>) iarq.readObject();
            listaAux = (ArrayList<Jogo>) iarq.readObject();
            times = (CadastroDeTimes) iarq.readObject();
            jogo15 = (Jogo) iarq.readObject();
            jogo14 = (Jogo) iarq.readObject();
            jogo13 = (Jogo) iarq.readObject();
            jogo12 = (Jogo) iarq.readObject();
            jogo11 = (Jogo) iarq.readObject();
            jogo10 = (Jogo) iarq.readObject();
            jogo9 = (Jogo) iarq.readObject();
            iarq.close();
            return true;
    	}
    	catch(IOException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            e.printStackTrace();
    	}
    	catch(ClassNotFoundException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            e.printStackTrace();
    	}
    	return false;
    }
    public int getNumJogo(){
        return numJogo;
    }

    public void atualizaSaldo(Jogo jogoDaVez){
        Time jA=jogoDaVez.getTimeA(),jB=jogoDaVez.getTimeB();
        for(int x=0;x<times.tamanho();x++){
            if(times.getTime(x).getNome().equalsIgnoreCase(jA.getNome())){
                    times.getTime(x).setGolsPro(jA.getGolsPro());
                    times.getTime(x).setGolsContra(jB.getGolsPro());
            }
        }
    }
    
    public void comparaSaldo(){
        JOptionPane.showMessageDialog(null, times.tamanho());
        times.comparaSaldo();
    }
    public String getMelhorAtaque(){
        times.comparaSaldo();
        return times.getMelhorAtaque();
    }
    
    public String getPiorDefesa(){
        times.comparaSaldo();
        return times.getPiorDefesa();
    }
     
    

}
