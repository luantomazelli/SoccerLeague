import java.io.*;
/*
 * @author LeandroS
 *         Luan Tomazelli 
 */
public class Jogador implements Serializable{
  
    private String nome, time;
    private int gols=0, totalGols;
    
    /** Creates a new instance of Jogador */
    public Jogador(String n, String t) {
        nome = n;
        time = t;
    }

    public void adicionaGol(){
        gols = gols+1;
    }
    
    public int getGols(){
        return gols;
    }
    public void resetGols(){
        gols = 0;
    }
    public int getTotalGols(){
        return totalGols;
    }
    public String getNome(){
        return nome;
    }
    public void setTime(String t){
        time = t;
    }
    public String getTime(){
        return time;
    }
    
    @Override
    public String toString(){
        return nome;
    }
    
}
