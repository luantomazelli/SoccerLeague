import java.io.Serializable;
import java.util.*;
/*
 * Jogo.java
 * 
 * Created on 11/11/2007, 22:26:23
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Leandro H.Soares
 *         Luan Tomazelli 
 */
public class Jogo implements Comparable<Jogo>, Serializable{
    private Time timeA, timeB, vencedor;
    private String nomeTA, nomeTB, nomePartida;
    private int golsA=0, golsB=0, numJogo;
    
    
    
    public Jogo(Time a, Time b, int n){
        timeA=a;
        timeB=b;
        nomeTA = timeA.getNome();
        nomeTB = timeB.getNome();
        numJogo=n;
        nomePartida = getNomeTimeA()+ " x "+getNomeTimeB();
    }
    
    public Jogo(String n1, String n2, int n){
        timeA=null;
        timeB=null;
        numJogo=n;
        nomeTA=n1;
        nomeTB=n2;
        nomePartida=nomeTA+" x "+nomeTB;
    }
    
    public Jogo(int n){
        timeA=null;
        timeB=null;
        numJogo=n;
        nomePartida="";
    }
    public Jogo(){
    }
    
    public void setTimeA(Time t){
        if(t==null)
            return;
        timeA=t;
        nomeTA=timeA.getNome();
    }
    
    public void setTimeB(Time t){
        if(t==null)
            return;
        timeB=t;
        nomeTB=timeB.getNome();
    }
    
    public Time getTimeA(){
        return timeA;
    }
    public Time getTimeB(){
        return timeB;
    }

    public void setGols(int gA, int gB){
        timeA.setGolsPro(gA);
        timeA.setGolsContra(gB);
        
        timeB.setGolsPro(gB);
        timeB.setGolsContra(gA);
    }
    
    public ArrayList getTimes(){
        ArrayList<Time> lista = new ArrayList<Time>(2);
        lista.add(timeA);
        lista.add(timeB);
        return lista;
    }
    
    @Override
    public String toString(){
        return nomePartida;
    }
    
    public String getNomeTimeA(){
        return nomeTA;
    }
    public ArrayList<Jogador> getEscalacaoTimeA(){
        return timeA.getEscalacao();
    }
    public ArrayList<Jogador> getEscalacaoTimeB(){
        return timeB.getEscalacao();        
    }
    
    public String getNomeTimeB(){
        return nomeTB;
    }
    public int getNumJogo(){
        return numJogo;
    }
    public Time getVencedor(){
        if(vencedor==null)
            return null;
        return vencedor;
        /*if(golsA>golsB)
            return timeA;
        else
            return timeB;*/
    }
    
    public void setVencedor(int time, int golsA, int golsB){
        if(time==1)
            vencedor=timeA;
        else
            vencedor=timeB;
        this.golsA=golsA;
        this.golsB=golsB;
    }
    
    public String getNomePartida(){
        return nomePartida;
    }

    @Override
    public int compareTo(Jogo game) {
        return nomePartida.compareTo(game.getNomePartida());
    }
    
    public int getGolsA(){
        if(golsA==golsB)
            if(vencedor==timeA)
                return 4;
            else
                return 3;
        return golsA;
    }
    public int getGolsB(){
        if(golsA==golsB)
            if(vencedor==timeA)
                return 3;
            else
                return 4;
        return golsB;
    }
}
