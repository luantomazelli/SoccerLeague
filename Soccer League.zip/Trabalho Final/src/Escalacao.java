import java.io.Serializable;
import java.util.*;
/*
 * Escalacao.java
 * 
 * Created on 02/11/2007, 20:31:55
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Leandro H.Soares
 *         Luan Tomazelli 
 */
public class Escalacao implements Serializable{
    private List<Jogador> lista;
    private Jogador jogador;
    
    
    public Escalacao(){
        lista = new ArrayList<Jogador>();
    }
    public boolean addJogador(Jogador j){
        return lista.add(j);
    }
    public void addJogador(Escalacao e){
        while(e.tamanho()>0){
            lista.add(e.get(0));
        }
    }
    public boolean addJogador(String jog, String time){
        Jogador j = new Jogador(jog, time);
        return lista.add(j);
    }
    
    public int tamanho(){
        return lista.size();
    }
    public Jogador get(int posicao){
        return lista.get(posicao);
    }
    
    public String todos(){
       String todos = "";
       if(tamanho()>0){
          for(Jogador j:lista)
             todos=todos+"\n"+j.toString();
       }
       else
           todos = "Nenhum jogador cadastrado";
       return todos;
    }
    public String toString(){
       String todos = "";
       if(tamanho()>0){
          for(Jogador j:lista)
             todos=todos+"\n"+j.toString();
       }
       else
           todos = "Nenhum jogador cadastrado";
       return todos;
    }
    
}
