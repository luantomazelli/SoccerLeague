import java.io.*;
import java.util.*;
import javax.swing.JOptionPane;
/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */


/**
 *
 * @author Leandro H.Soares
 *         Luan Tomazelli 
 */
public class Artilheiro implements Serializable{
    private ArrayList<Jogador> lista;
    
    
    public Artilheiro(){
         lista = new ArrayList<Jogador>();
    }
    
    public boolean adicionaJogador(Jogador j){
        if(!contem(j))
            lista.add(j);
        return adicionaGol(j);
    }
    
    public boolean adicionaGol(Jogador j){
        for(Jogador aux:lista)
            if(aux.getNome().equalsIgnoreCase(j.getNome()))
                if(aux.getTime().equalsIgnoreCase(j.getTime())){
                    j.adicionaGol();
                    //ordena a lista pelo n� de gols de cada jogador
                    comparaGols();
                    return true;
                }
        return false;
    }
    
    public String goleador(){
        if(isEmpty())
            return "Nenhum jogador fez gol at� o momento";
        return lista.get(0).getNome()+", do time "+lista.get(0).getTime()+" � o artilheiro, com "+lista.get(0).getGols()+" gols.";
        //return lista.get(0).getNome();
    }
    
    public String golsGoleador(){
        if (isEmpty())
            return "Nenhum gol";
        return ""+lista.get(0).getGols();
    }
    
    public String timeGoleador(){
        if (isEmpty())
            return "";
        return lista.get(0).getTime();
    }
    
    public boolean contem(Jogador j){
        for(Jogador aux:lista)
            if(aux.getNome().equalsIgnoreCase(j.getNome()))
                if(aux.getTime().equalsIgnoreCase(j.getTime()))
                    return true;
        return false;
    }
    
    public boolean isEmpty(){
        return lista.isEmpty();
    }
    public int tamanho(){
        return lista.size();
    }
    
    public void comparaGols(){
        Jogador j1,j2;
        for(int i=0; i<(tamanho()-1); i++){
            if(lista.get(i).getGols()<lista.get(i+1).getGols()){
                j1=lista.get(i);
                j2=lista.get(i+1);
                lista.set(i, j2);
                lista.set(i+1, j1);
                i=0;
            }
        }
    }
    
    public String todos(){
       String todos = "";
       if(tamanho()>0){
          for(Jogador j:lista)
             todos=todos+"\n"+j.toString();
       }
       else
           todos = "Nenhum jogador cadastrado";
       return todos;
    }
    
    public boolean gravaArquivoBinario(){
        try{
            FileOutputStream os = new FileOutputStream("artilheiros.jog");
            ObjectOutputStream oarq = new ObjectOutputStream(os);
            oarq.writeObject(lista);
            oarq.close();
            return true;
    	}
    	catch(IOException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            e.printStackTrace();
    	}
    	return false;
    }
    @SuppressWarnings("unchecked")
    public boolean leArquivoBinario(){ 
    	try{
            FileInputStream is = new FileInputStream("artilheiros.jog");
            ObjectInputStream iarq = new ObjectInputStream(is);
            lista = (ArrayList<Jogador>) iarq.readObject();
            iarq.close();
            return true;
    	}
    	catch(IOException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            e.printStackTrace();
    	}
    	catch(ClassNotFoundException e){
            JOptionPane.showMessageDialog(null,e.getMessage());
            e.printStackTrace();
    	}
       	return false;
    }  
}