import java.util.ArrayList;

/**
 * Implementa��o de uma �rvore bin�ria de pesquisa.
 * 
 * @author Isabel H. Manssour 
 * @version novembro/2007
 */

public class ArvoreBinariaPesquisa<E extends Comparable<E>>
{
	// Atributo 
    private Nodo<E> raiz;
    
    // Classe interna  
    private class Nodo<T> {
        private T element;
        private Nodo<T> esq;
        private Nodo<T> dir;
        public Nodo(T e) {
            element = e;
            esq = null;
            dir = null;
        }
        public void setElement(T e) {
            element = e; 
        }
        public void setEsquerda (Nodo<T> n) { 
            esq = n; 
        }
        public void setDireita (Nodo<T> n) { 
            dir = n; 
        }        
        public T getElement() { 
            return element; 
        }
        public Nodo<T> getEsquerda() { 
            return esq; 
        }
        public Nodo<T> getDireita() { 
            return dir; 
        }
    }
    
    // Construtor
    public ArvoreBinariaPesquisa()
    {
        raiz = null;
    }

    // M�todo que retorna verdadeiro quando encontra o 
    // objeto "e" na �rvore bin�ria, e falso caso contr�rio.
    public boolean pesquisa(E e)
    {
        Nodo<E> aux = pesquisa(raiz,e);

        if (aux == null)
          return false;

        return true;
    }

    // M�todo recursivo e privado que procura um objeto e na 
    // �rvore, quando o encontra devolve a refer�ncia para o 
    // nodo que o cont�m.
    private Nodo<E> pesquisa(Nodo<E> a, E e)
    {
        int r;

        if (a == null || e == null)
          return null;
        
        r = a.getElement().compareTo(e);
        
        if (r == 0)
          return a;
        else if (r > 0)
            return pesquisa(a.getEsquerda(),e);
        else
            return pesquisa(a.getDireita(),e);
    }    
    
    // M�todo que insere o elemento "e" na ABP. Este elemento n�o
    // pode ser null nem pode j� ser repetido na ABP.
    public boolean insere(E e) {
        if ( e == null || pesquisa(e) )
            return false;
        raiz = insere(raiz, e);
        return true;
    }
    
    // M�todo recursivo para inser��o de um elemento na ABP.
    private Nodo<E> insere(Nodo<E> a, E e) {
        if (e == null)
            return a;
        if (a == null)
            return new Nodo<E>(e);
        if ( a.getElement().compareTo(e) < 0 )
            a.setDireita( insere(a.getDireita(),e) );
        else
            a.setEsquerda( insere(a.getEsquerda(),e) );
        return a;
    }

    // M�todo para remover da ABP o elemento "e" passado como par�metro. 
    // Ele chama o m�todo recursivo e sobrecarregado apresentado mais abaixo.
    public boolean remove(E e) {
        Nodo<E> aux;
        if (e == null || raiz == null)
            return false;
        aux = pesquisa(raiz,e);
        if (aux == null)
            return false;
        remove(aux);
        return true;    
    }    
    
    private void remove (Nodo<E> n){
        Nodo<E> aux, m;
        aux = pesquisaNodoPai(n);
        if (n.getEsquerda() == null) {
            if (n.getDireita() == null) {  //Nodo a excluir � Folha
                if (raiz == n) {
                    raiz = null;
                    return;
                }
                if (aux.getEsquerda() == n)
                    aux.setEsquerda(null);
                else
                    aux.setDireita(null);
                return;
            }
            else { //Esquerda Nula e Direita N�o
                if (raiz == n) {
                    raiz = n.getDireita();    
                    return;
                }    
                if (aux.getEsquerda() == n) 
                    aux.setEsquerda(n.getDireita());
                else 
                    aux.setDireita(n.getDireita());
            }
            return;
        }

        if ( n.getDireita() == null ) { //Direita Nula e Esquerda N�o
            if (raiz == n) {
                 raiz = n.getEsquerda();    
                 return;
            }                
            if ( aux.getEsquerda() == n )
                 aux.setEsquerda(n.getEsquerda());
            else 
                 aux.setDireita(n.getEsquerda());
            return;
        }

        //Esquerda e Direita N�o Nulas
        m = maior(n.getEsquerda());
        n.setElement(m.getElement());
        remove(m); //remove(m);
    }    

    // M�todo que retorna a refer�ncia para o nodo pai do nodo onde 
    // est� armazenado o elemento "e" passado como par�metro.
    private Nodo<E> pesquisaNodoPai(E e)
    {
        if (e == null || raiz == null)
            return null;
        Nodo<E> n = pesquisa(raiz,e);
        Nodo<E> pai = pesquisaPai(raiz, n, null);
        return pai;
    }
    
    // M�todo que retorna a refer�ncia para o nodo pai do nodo passado 
    // como par�metro.   
    private Nodo<E> pesquisaNodoPai(Nodo<E> n)
    {
        if (n == raiz)
            return null;
        Nodo<E> a = pesquisaPai(raiz, n, null);
        return a;
    }
    
    // M�todo recursivo utilizado para retornar a refer�ncia para o nodo pai
    // do nodo "n" passado como par�metro.      
    private Nodo<E> pesquisaPai(Nodo<E> a, Nodo<E> n, Nodo<E> pai)
    {
        Nodo<E> aux; 

        if (a == null)
          return null;
        if ( a == n )
          return pai;

        aux = pesquisaPai(a.getEsquerda(), n, a);
        if (aux==null)
          aux = pesquisaPai(a.getDireita(), n, a);

        return aux;
    } 
    
    
    // M�todo que retorna o maior elemento armazenado na �rvore.
    public E maior(){
        Nodo<E> aux = maior(raiz);
        if (aux == null)
          return null;
        return aux.getElement();        
    }
    
    // M�todo privado e recursivo que devolve a refer�ncia do 
    // nodo que cont�m o maior objeto da �rvore
    private Nodo<E> maior(Nodo<E> a){
        if (a == null)
          return null;
        if (a.getDireita() == null)
          return a;
        return maior(a.getDireita());
      
    }    
    
    // M�todo que retorna o elemento pai de "e".
    public E getPai(E e){
        Nodo<E> p = pesquisaNodoPai(e); 
        if (p != null)
        	return p.getElement();
        else
        	return null;        
    }
    
    // M�todo que retorna o elemento que est� � esquerda de "e".
    public E getEsquerda(E e){
        Nodo<E> aux = pesquisa(raiz,e); 
        if (aux != null)
        {
            if (aux.getEsquerda() != null)
                return aux.getEsquerda().getElement();
        }
        return null;        
    }

    // M�todo que retorna o elemento que est� � direita de "e".
    public E getDireita(E e){
        Nodo<E> aux = pesquisa(raiz,e); 
        if (aux != null)
        {
            if (aux.getDireita() != null)
                return aux.getDireita().getElement();
        }
        return null;
    }    
    
    // M�todo que retorna o elemento que est� na raiz da ABP.
    public E getRaiz(){
        if (raiz != null)
            return raiz.getElement();
        else    
            return null;
    }  

    // M�todo que retorna a altura da ABP e chama o m�todo recursivo
    // implementado mais abaixo.
    public int altura () {
        return altura(raiz);
    }    
        
    private int altura (Nodo<E> n) {
        if (n == null) 
            return -1;
        else {
            int alturaEsq = altura (n.getEsquerda());
            int alturaDireita = altura (n.getDireita());
            if (alturaEsq < alturaDireita) 
                return alturaDireita + 1;
            else 
                return alturaEsq + 1;
        }
    }     
       
    // M�todo que substitui um elemento da ABP por outro passado
    // como par�metro.
    public boolean trocaElemento(E novo, E velho) {
    	boolean b = remove(velho);
    	if (b==true){
    		b = insere(novo);
    		if (b==true)
    			return true;
    		else {
    			insere(velho);
    			return false;
    		}
    	}
    	else
    		return false;
    }    
    
    // M�todo que retorna verdadeiro se a ABP est� vazia e falso 
    // caso contr�rio.
    public boolean estaVazia() {
        if (raiz == null)
            return true;
        else
            return false;
    } 
    
    // M�todo que retorna o total de elementos armazenados na �rvore, 
    // que chama o m�todo recursivo implementado mais abaixo.
    public int getTotalElementos()
    {
        return quantidadeElementos(raiz);
    }

    private int quantidadeElementos(Nodo<E> a)
    {
        if (a == null )
            return 0;
        return quantidadeElementos(a.getEsquerda()) + quantidadeElementos(a.getDireita()) + 1;
    }   
    
    // M�todo que verifica se um determinado elemento � a raiz da �rvore,
    // retornando verdadeiro, em caso positivo, e falso, caso contr�rio.
    public boolean ehRaiz(E d)
    {
    	if (raiz!=null)
    		if (raiz.getElement().equals(d))
    			return true;
        return false;
    }

    // M�todo que retorna o nivel do elemento "e" na �rvore.
    public int nivel(E e)
    {
        Nodo<E> aux = pesquisa(raiz,e);
        if (aux == null)
            return -1;    
        Nodo<E> pai = pesquisaNodoPai(e);
        if (pai == null)
            return 0;
        else
            return 1 + nivel(pai.getElement());
    }    
    
    // M�todo que verifica se um determinado elemento est� 
    // armazenado em um nodo folha da ABP.
    public boolean ehFolha(E d)
    {
        if (raiz == null)
            return false;
            
        Nodo<E> aux = pesquisa(raiz,d);
        if (aux == null)
            return false;
        else if (aux.getEsquerda()==null && aux.getDireita()==null)
            return true;
        else
            return false;
    }
    
    // M�todo que verifica se um determinado elemento est� 
    // armazenado em um nodo interno da ABP.    
    public boolean ehInterno(E d){
        if(!pesquisa(d)) 
            return false;
        if(pesquisaNodoPai(d)==null)
            return false;
        Nodo<E> aux = pesquisa(raiz, d);
        if(aux.getDireita()!=null || aux.getEsquerda()!=null)
            return true;
        return false;
        
        // Tarefa 3
        //
        // Implemente este m�todo que recebe um elemento e retorna
        // verdadeiro se este elemento estiver armazenado em um nodo
        // interno, e falso caso contr�rio.
    }    
    
    // M�todo que retorna um ArrayList que cont�m todos os elementos
    // armazenados na AB em ordem crescente, e chama o m�todo recursivo
    // implementado mais abaixo.
    public ArrayList<E> retornaElementosOrdenados()
    {
    	ArrayList<E> array = new ArrayList<E>();
    	incluiElementosOrdenados(array,raiz);
    	return array;
    }
    
    private void incluiElementosOrdenados(ArrayList<E> array, Nodo<E> n)
    {
        if (n != null)
        {
        	incluiElementosOrdenados(array,n.getEsquerda());
        	array.add(n.getElement());
        	incluiElementosOrdenados(array,n.getDireita());
        }
        return;
    }    
}
